# VitalTech S.A.S. – Plataforma web

Sitio corporativo de VitalTech S.A.S. (Bogotá D.C.): soluciones QR/NFC para acceder a información médica en emergencias.

## Ver el sitio
Abra `index.html` en el navegador (no requiere instalación) o publíquelo con GitHub Pages.

## Contenido
Inicio, Nosotros, Soluciones, ¿Cómo funciona?, Portafolio y cotización, Mercado, Innovación, Dashboard (demo), Portal de clientes (demo), Contenidos, Alianzas y Contacto. Incluye chatbot, buscador y tema claro/oscuro.

## Importante: es una demostración
- Formularios, registro, login y dashboard funcionan solo en el navegador (`localStorage`). No hay backend.
- **No ingrese información médica real.**
- Acceso demo del dashboard: `admin@vitaltech.demo` / `Demo2026!` (la validación debe moverse a un servidor en producción).
- Cifras financieras: son proyecciones del modelo del proyecto, no resultados históricos.

## Pendiente para producción
Servidor y base de datos cifrada, HTTPS, envío de correo/CRM, WhatsApp, datos de contacto reales, sitemap, política de privacidad y términos completos (Ley 1581 de 2012).

Fuentes: documento del proyecto productivo SENA (Ficha 3385498) y modelo financiero MFIN Industrial, 4-11-2026.
